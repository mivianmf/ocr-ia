/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ocr.interfaces;

/**
 *
 * @author 407456
 */
public interface Drawer_Observer {
    public void atualizar(Drawer_Observable observavel);
}
