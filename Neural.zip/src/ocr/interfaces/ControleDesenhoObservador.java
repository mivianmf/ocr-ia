/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ocr.interfaces;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;

/**
 *
 * @author Rubico
 */
public interface ControleDesenhoObservador {
    
    //void setColor(Color color);

    void limpar();

    //void mudarImagemSelecionada(BufferedImage img);
    
}
