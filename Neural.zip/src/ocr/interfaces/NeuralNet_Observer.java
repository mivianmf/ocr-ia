/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ocr.interfaces;

/**
 *
 * @author Bruno, Mívian e Washington
 */
public interface NeuralNet_Observer {
    public void atualizar(NeuralNet_Observable observavel);
}
