/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ocr.interfaces;

/**
 *
 * @author WashingtonLuis
 */
public interface BotaoReconhecer_Observer {
    public void atualizar(BotaoReconhecer_Observable observavel);    
}
